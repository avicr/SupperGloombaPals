<?xml version="1.0" encoding="UTF-8"?>
<tileset name="title" tilewidth="64" tileheight="64" tilecount="72" columns="12">
 <image source="../textures/title_64x64.bmp" trans="ff00ff" width="768" height="384"/>
</tileset>
