<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Basic32x32" tilewidth="32" tileheight="32" tilecount="90" columns="18" backgroundcolor="#9298e2">
 <image source="../textures/tilesheet01.bmp" trans="ff00ff" width="576" height="160"/>
 <tile id="0" type="BLOCK"/>
 <tile id="1" type="BLOCK"/>
 <tile id="16" type="Goomba"/>
 <tile id="17" type="Goomba"/>
 <tile id="18" type="BLOCK"/>
 <tile id="19" type="BLOCK"/>
 <tile id="34" type="Goomba"/>
 <tile id="35" type="Goomba"/>
 <tile id="46" type="ITEM"/>
 <tile id="47" type="ITEM"/>
 <tile id="48" type="WARP"/>
 <tile id="49" type="WARP"/>
 <tile id="64" type="ITEM"/>
 <tile id="65" type="ITEM"/>
 <tile id="66" type="WARP"/>
 <tile id="67" type="WARP"/>
</tileset>
