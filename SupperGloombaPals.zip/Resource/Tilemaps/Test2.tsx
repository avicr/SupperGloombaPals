<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Test2" tilewidth="32" tileheight="32" tilecount="90" columns="18">
 <image source="../textures/tilesheet01.bmp" trans="ff00ff" width="576" height="160"/>
</tileset>
