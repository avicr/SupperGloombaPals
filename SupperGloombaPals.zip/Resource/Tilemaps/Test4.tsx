<?xml version="1.0" encoding="UTF-8"?>
<tileset name="test4" tilewidth="16" tileheight="16" tilecount="360" columns="36">
 <image source="../textures/tilesheet01.bmp" trans="ff00ff" width="576" height="160"/>
</tileset>
